create definer = root@localhost view emp_view30 as
select `e`.`EMPNO`  AS `empno`,
       `e`.`ENAME`  AS `ename`,
       `e`.`SAL`    AS `sal`,
       `s`.`GRADE`  AS `grade`,
       `e`.`DEPTNO` AS `deptno`,
       `d`.`DNAME`  AS `dname`
from ((`ureca`.`emp_copy` `e` join `ureca`.`salgrade` `s`
       on ((`e`.`SAL` between `s`.`LOSAL` and `s`.`HISAL`))) join `ureca`.`dept` `d` on ((`e`.`DEPTNO` = `d`.`DEPTNO`)))
where (`e`.`DEPTNO` = 30);

